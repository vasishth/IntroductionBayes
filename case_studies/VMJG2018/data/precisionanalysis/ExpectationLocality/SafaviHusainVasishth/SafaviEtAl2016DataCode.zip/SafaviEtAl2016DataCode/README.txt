This directory contains the R code and data needed for reproducing the results reported in Safavi, Husain and Vasishth 2016. Also provided are item files and details on the treebank statistics and pretests.

Please contact Shravan Vasishth for any questions.  